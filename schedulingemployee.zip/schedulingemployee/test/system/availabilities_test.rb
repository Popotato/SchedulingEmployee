require "application_system_test_case"

class AvailabilitiesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit availabilities_url
  #
  #   assert_selector "h1", text: "Availability"
  # end
end
