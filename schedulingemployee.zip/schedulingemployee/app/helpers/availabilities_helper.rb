module AvailabilitiesHelper
end
