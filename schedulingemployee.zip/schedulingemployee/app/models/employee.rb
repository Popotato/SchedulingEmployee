class Employee < ApplicationRecord
end
