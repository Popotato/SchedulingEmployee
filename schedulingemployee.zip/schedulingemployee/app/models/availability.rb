class Availability < ApplicationRecord
  belongs_to :employee
end
